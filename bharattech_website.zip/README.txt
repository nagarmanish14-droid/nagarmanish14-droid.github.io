BharatTech Materials Website
---------------------------------

Files included:
- index.html
- styles.css
- script.js

How to deploy on Hostinger:
1. Log in to Hostinger hPanel.
2. Open your hosting for **bharattechmaterials.org**.
3. Go to **Files → File Manager**.
4. Upload the ZIP file and extract it into `public_html`.
5. Ensure index.html is in the root of public_html.
6. Your site will be live instantly.

Need updates? I can:
- Add product pages
- Add WhatsApp chat button
- Add quote request backend
- Add catalogs or PDF downloads
- Add animations
