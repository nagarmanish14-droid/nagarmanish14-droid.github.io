
document.getElementById('menuToggle').addEventListener('click', function(){
  const nav = document.querySelector('.nav');
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  nav.style.flexDirection = 'column';
  nav.style.background = '#0a1a2f';
  nav.style.position = 'absolute';
  nav.style.top = '60px';
  nav.style.right = '20px';
  nav.style.padding = '1rem';
  nav.style.borderRadius = '8px';
});
